export default { // 注意，对象要抛出后，其他文件中才能引入使用
    host: 'http://api.uric.cn:8000' // 我们的后台项目将来就通过这个域名和端口来启动
}